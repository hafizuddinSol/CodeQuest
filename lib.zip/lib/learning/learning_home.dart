import 'package:flutter/material.dart';
import 'tips_of_the_day.dart';
import 'learning_teacher.dart';
import 'learning_student.dart';

class LearningHome extends StatelessWidget {
  final String role; // "Teacher" or "Student"
  const LearningHome({super.key, required this.role});

  @override
  Widget build(BuildContext context) {
    return TipsOfTheDay(
      // onNext: () {
      //   if (role == "Teacher") {
      //     Navigator.pushReplacement(
      //       context,
      //       MaterialPageRoute(builder: (_) => const LearningTeacherPage()),
      //     );
      //   } else {
      //     Navigator.pushReplacement(
      //       context,
      //       MaterialPageRoute(builder: (_) => const LearningStudentPage()),
      //     );
      //   }
      // },
    );
  }
}
